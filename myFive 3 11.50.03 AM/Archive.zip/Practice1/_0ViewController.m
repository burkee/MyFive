//
//  _0ViewController.m
//  Practice1
//
//  Created by Derek Hsieh on 11/14/13.
//  Copyright (c) 2013 Derek Hsieh. All rights reserved.
//

#import "_0ViewController.h"

@interface _0ViewController ()

@end

@implementation _0ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
